enum BookingStatus { inquiry, booked }

class Booking {
  final String id;
  final String service;
  final DateTime start;
  final int durationMinutes;
  BookingStatus status;
  String? note;
  final bool importedFromDeviceCalendar;
  final bool isAllDay;

  Booking({
    required this.id,
    required this.service,
    required this.start,
    required this.durationMinutes,
    required this.status,
    this.note,
    this.importedFromDeviceCalendar = false,
    this.isAllDay = false,
  });

  DateTime get end => start.add(Duration(minutes: durationMinutes));

  String get timeText {
    if (isAllDay) return 'Cały dzień';
    return '${_two(start.hour)}:${_two(start.minute)} - ${_two(end.hour)}:${_two(end.minute)}';
  }

  static String _two(int v) => v.toString().padLeft(2, '0');
}