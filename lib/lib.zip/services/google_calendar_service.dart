import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/booking.dart';
import 'auth_service.dart';

/// Pobiera eventy z Google Calendar API v3.
/// Wymaga scope: https://www.googleapis.com/auth/calendar.readonly
/// Działa na wszystkich platformach (Android, Web, iOS, Desktop).
class GoogleCalendarService {
  GoogleCalendarService._();
  static final GoogleCalendarService instance = GoogleCalendarService._();

  static const _base = 'https://www.googleapis.com/calendar/v3';

  /// Pobiera eventy z podstawowego kalendarza użytkownika.
  /// Rzuca [GoogleCalendarNotSignedInException] gdy brak sesji.
  /// Rzuca [GoogleCalendarApiException] przy błędzie API.
  Future<List<Booking>> fetchEvents(DateTime from, DateTime to) async {
    final token = await AuthService.instance.getAccessToken();
    if (token == null) throw GoogleCalendarNotSignedInException();

    final uri = Uri.parse('$_base/calendars/primary/events').replace(
      queryParameters: {
        'timeMin': from.toUtc().toIso8601String(),
        'timeMax': to.toUtc().toIso8601String(),
        'singleEvents': 'true',   // rozwiń cykliczne eventy
        'orderBy': 'startTime',
        'maxResults': '500',
      },
    );

    final response = await http.get(uri, headers: {
      'Authorization': 'Bearer $token',
      'Accept': 'application/json',
    });

    if (response.statusCode == 401) {
      throw GoogleCalendarNotSignedInException();
    }
    if (response.statusCode != 200) {
      throw GoogleCalendarApiException(
          'HTTP ${response.statusCode}: ${response.body}');
    }

    final data = json.decode(response.body) as Map<String, dynamic>;
    final items = (data['items'] as List?) ?? [];

    final bookings = <Booking>[];
    for (final item in items) {
      final b = _parseEvent(item as Map<String, dynamic>);
      if (b != null) bookings.add(b);
    }
    return bookings;
  }

  Booking? _parseEvent(Map<String, dynamic> item) {
    final summary = (item['summary'] as String?)?.trim();
    if (summary == null || summary.isEmpty) return null;

    final id = item['id'] as String? ??
        DateTime.now().millisecondsSinceEpoch.toString();

    // Czas start
    final startMap = item['start'] as Map<String, dynamic>?;
    if (startMap == null) return null;
    final startStr =
        startMap['dateTime'] as String? ?? startMap['date'] as String?;
    if (startStr == null) return null;
    final isAllDay = startMap['dateTime'] == null;

    // Czas end
    final endMap = item['end'] as Map<String, dynamic>?;
    final endStr =
        endMap?['dateTime'] as String? ?? endMap?['date'] as String?;

    DateTime start;
    DateTime end;
    try {
      start = DateTime.parse(startStr).toLocal();
      end = endStr != null
          ? DateTime.parse(endStr).toLocal()
          : start.add(const Duration(hours: 1));
    } catch (_) {
      return null;
    }

    int duration = end.difference(start).inMinutes;
    // Całodniowe: end jest dniem po starcie (YYYY-MM-DD), duration może wyjść 0
    if (isAllDay && duration <= 0) duration = 24 * 60;
    if (duration <= 0) duration = 60;

    return Booking(
      id: 'gcal:$id',
      service: summary,
      start: start,
      durationMinutes: duration,
      status: BookingStatus.booked,
      note: 'Google Calendar',
      importedFromDeviceCalendar: true,
      isAllDay: isAllDay,
    );
  }
}

class GoogleCalendarNotSignedInException implements Exception {
  @override
  String toString() => 'Nie jesteś zalogowany przez Google';
}

class GoogleCalendarApiException implements Exception {
  final String message;
  GoogleCalendarApiException(this.message);
  @override
  String toString() => 'Błąd Google Calendar API: $message';
}
