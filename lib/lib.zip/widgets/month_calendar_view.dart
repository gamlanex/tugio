import 'package:flutter/material.dart';
import '../models/booking.dart';
import '../utils/date_helpers.dart';

class MonthCalendarView extends StatelessWidget {
  final DateTime selectedDate;
  final List<Booking> bookings;
  final void Function(DateTime day) onDayTap;
  final double maxHeight;
  final List<String> freeSlots;
  final int slotDurationMinutes;

  const MonthCalendarView({
    super.key,
    required this.selectedDate,
    required this.bookings,
    required this.onDayTap,
    this.maxHeight = 600,
    this.freeSlots = const [],
    this.slotDurationMinutes = 60,
  });

  // Godziny widoczne w widoku dnia (7:00–21:00)
  static const int _startHour = 7;
  static const int _endHour = 21;

  @override
  Widget build(BuildContext context) {
    final firstOfMonth = DateTime(selectedDate.year, selectedDate.month, 1);
    final gridStart = firstOfMonth.subtract(
      Duration(days: firstOfMonth.weekday - 1),
    );
    final days = List.generate(42, (i) => gridStart.add(Duration(days: i)));

    const double targetCellHeight = 72.0;
    const double headerHeight = 28.0;
    const double rowSpacing = 6.0;
    const int rowCount = 6;

    final totalGridH =
        rowCount * targetCellHeight + (rowCount - 1) * rowSpacing;
    final totalH = headerHeight + totalGridH;
    final scale = (totalH > maxHeight) ? (maxHeight / totalH) : 1.0;
    final cellHeight = targetCellHeight * scale;

    return LayoutBuilder(
      builder: (context, constraints) {
        final availableWidth =
            constraints.maxWidth > 0 ? constraints.maxWidth : 300.0;
        final cellWidth = (availableWidth - 6 * rowSpacing) / 7;
        final aspectRatio = cellWidth / cellHeight;

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── nagłówki dni tygodnia ──────────────────────
            SizedBox(
              height: headerHeight,
              child: Row(
                children: List.generate(7, (i) {
                  return Expanded(
                    child: Center(
                      child: Text(
                        weekdayShort(i + 1),
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.grey.shade700,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),

            // ── siatka dni ────────────────────────────────
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: days.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                mainAxisSpacing: rowSpacing,
                crossAxisSpacing: rowSpacing,
                childAspectRatio: aspectRatio,
              ),
              itemBuilder: (context, index) {
                final day = days[index];
                final isCurrentMonth = day.month == selectedDate.month;
                final isSelected = sameDay(day, selectedDate);
                final isToday = sameDay(day, DateTime.now());

                final dayBookings = bookings
                    .where((b) => sameDay(b.start, day))
                    .toList()
                  ..sort((a, b) => a.start.compareTo(b.start));
                final visibleBars = dayBookings.take(2).toList();

                // Wolne sloty dla tego dnia (nieobsadzone)
                final dayFreeSlots = isCurrentMonth
                    ? _freeSlotsForDay(day, dayBookings)
                    : <_SlotPos>[];
                final hasFreeSlots = dayFreeSlots.isNotEmpty;

                return InkWell(
                  onTap: () => onDayTap(day),
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(4, 4, 8, 3),
                    decoration: BoxDecoration(
                      // Delikatne niebieskie tło gdy są wolne sloty
                      color: isToday
                          ? Colors.indigo.withOpacity(0.13)
                          : isSelected
                              ? Colors.indigo.withOpacity(0.08)
                              : hasFreeSlots && isCurrentMonth
                                  ? Colors.blue.withOpacity(0.04)
                                  : isCurrentMonth
                                      ? Colors.white
                                      : Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isToday
                            ? Colors.indigo
                            : isSelected
                                ? Colors.indigo.withOpacity(0.5)
                                : Colors.black12,
                        width: isToday ? 1.6 : 1,
                      ),
                    ),
                    child: Stack(
                      clipBehavior: Clip.hardEdge,
                      children: [
                        // ── kółeczka po prawej ──────────────
                        if (hasFreeSlots && isCurrentMonth)
                          Positioned(
                            top: 4,
                            bottom: 4,
                            right: 1,
                            width: 6,
                            child: _SlotDots(slots: dayFreeSlots),
                          ),

                        // ── treść komórki ────────────────────
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Numer dnia
                            isToday
                                ? Container(
                                    width: 20,
                                    height: 20,
                                    decoration: const BoxDecoration(
                                      color: Colors.indigo,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Center(
                                      child: Text(
                                        '${day.day}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 10,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                  )
                                : Text(
                                    '${day.day}',
                                    maxLines: 1,
                                    style: TextStyle(
                                      fontWeight: isSelected
                                          ? FontWeight.w800
                                          : FontWeight.w600,
                                      fontSize: 11,
                                      color: isCurrentMonth
                                          ? Colors.black87
                                          : Colors.grey,
                                      height: 1.0,
                                    ),
                                  ),
                            const SizedBox(height: 3),
                            // Paseczki rezerwacji
                            ...visibleBars.map((b) {
                              final color =
                                  b.status == BookingStatus.booked
                                      ? Colors.green
                                      : Colors.orange;
                              return Container(
                                height: 5,
                                width: double.infinity,
                                margin: const EdgeInsets.only(bottom: 2),
                                decoration: BoxDecoration(
                                  color: color.withOpacity(0.85),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              );
                            }),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  /// Zwraca pozycje środków wolnych slotów jako ułamek [0,1] zakresu dnia.
  List<_SlotPos> _freeSlotsForDay(DateTime day, List<Booking> dayBookings) {
    final result = <_SlotPos>[];
    final totalMinutes = (_endHour - _startHour) * 60.0;

    for (final slot in freeSlots) {
      final parts = slot.split(':');
      if (parts.length < 2) continue;
      final hour = int.tryParse(parts[0]) ?? -1;
      final minute = int.tryParse(parts[1]) ?? 0;
      if (hour < _startHour || hour >= _endHour) continue;

      final slotStart = DateTime(day.year, day.month, day.day, hour, minute);
      final slotEnd = slotStart.add(Duration(minutes: slotDurationMinutes));

      final isOccupied = dayBookings.any(
        (b) => b.start.isBefore(slotEnd) && b.end.isAfter(slotStart),
      );
      if (isOccupied) continue;

      // Środek slotu jako ułamek
      final midMinutes = (hour - _startHour) * 60.0 +
          minute +
          slotDurationMinutes / 2.0;
      final fraction = (midMinutes / totalMinutes).clamp(0.0, 1.0);
      result.add(_SlotPos(fraction));
    }
    return result;
  }
}

// ─── Model pozycji slotu (ułamek 0–1 w zakresie dnia) ────────────────────────
class _SlotPos {
  final double fraction; // środek slotu jako ułamek wysokości komórki
  const _SlotPos(this.fraction);
}

// ─── Mikro-kółeczka po prawej, proporcjonalne do czasu ───────────────────────
class _SlotDots extends StatelessWidget {
  final List<_SlotPos> slots;
  const _SlotDots({super.key, required this.slots});

  static const double _d = 4.0;   // średnica kółka
  static const double _minGap = 5.0; // minimalny odstęp między środkami

  /// Rozsuwamy kółeczka jeśli są za blisko (algorytm pass-through).
  List<double> _spread(List<double> rawY, double totalH) {
    if (rawY.isEmpty) return rawY;
    final sorted = [...rawY]..sort();
    final out = List<double>.from(sorted);

    // Przesunięcie w górę gdy za blisko poprzedniego
    for (var i = 1; i < out.length; i++) {
      if (out[i] - out[i - 1] < _minGap) {
        out[i] = out[i - 1] + _minGap;
      }
    }
    // Jeśli wyszliśmy poza dolną krawędź — przesuń wszystko w górę
    final overflow = out.last + _d / 2 - totalH;
    if (overflow > 0) {
      for (var i = 0; i < out.length; i++) {
        out[i] = (out[i] - overflow).clamp(_d / 2, totalH - _d / 2);
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final h = constraints.maxHeight;
      final rawY = slots.map((s) => s.fraction * h).toList();
      final positions = _spread(rawY, h);

      return Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          for (var i = 0; i < positions.length; i++)
            Positioned(
              // Wyśrodkuj kółko poziomo i pionowo na wyliczonej pozycji
              top: positions[i] - _d / 2,
              left: 0,
              right: 0,
              height: _d,
              child: Center(
                child: Container(
                  width: _d,
                  height: _d,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.blue.shade500,
                      width: 1.2,
                    ),
                  ),
                ),
              ),
            ),
        ],
      );
    });
  }
}
